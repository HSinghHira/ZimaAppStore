---
name: "zimaos-app-creator"
description: Use when adding a new app or updating an existing app in Hira's Zima OS App Store (the HSinghHira/ZimaAppStore GitHub repo) — producing a compliant docker-compose.yml with x-casaos metadata, claiming a port, handling secrets/env vars, writing the README.md table row, and running the pre-push checklist. Trigger on requests like "add an app to the Zima app store", "publish an app to ZimaAppStore", "write a docker-compose.yml for the app store", or "update a ZimaAppStore manifest".
---

# Adding/updating an app in Hira's Zima OS App Store

This store is a curated collection of `docker-compose.yml` manifests, built
with `IceWhaleTech/build-appstore-action`, that let Zima OS users install
self-hosted apps with one click. This skill turns an upstream app's
name/image/ports/env vars into a compliant manifest and a matching
README row.

## Step 0 — get the current port ledger (do this first, every time)

The port ledger changes constantly, so it is **not** bundled in this
skill. Before doing anything else, fetch the live version from GitHub:

```
https://raw.githubusercontent.com/HSinghHira/ZimaAppStore/refs/heads/main/.claude/references/PORT_LEDGER.md
```

Use this fetched table as the source of truth for the next unused port —
ignore any port numbers you might recall from a previous conversation,
they may be stale. Also search the ledger for the app's name first: it
may already be listed.

If `web_fetch` refuses the URL (it only opens URLs it has already seen),
fetch it from the shell instead: `curl -sS <url>` — `raw.githubusercontent.com`
is reachable from the sandbox. If every fetch fails, stop and ask the user
to paste the current ledger instead of guessing a port number.

## Order of operations

0. **Read `references/VARIABLES.md` before writing anything.** It is not
   optional background. It decides what goes in `TZ`, `PUID`, `PGID`,
   every app-URL variable, every listen-port variable, and every
   healthcheck. Skipping it was a real mistake on a past run.
1. **Claim a port** from the fetched ledger (see Step 0). Note the
   number(s) you're using and tell the user to add the row to
   `PORT_LEDGER.md` in the repo before merging — this skill can't write
   back to GitHub itself.
2. **Write `docker-compose.yml`** following `references/ARCHITECTURE.md`
   exactly — required top-level keys, per-service keys, the `x-casaos`
   block. Use dynamic variables per `references/VARIABLES.md`:
   `TZ=$TZ` and `PUID=$PUID`/`PGID=$PGID` (only if upstream lists them).
   Never hardcode a time zone or an IP. Do **not** use `$PORT` — use
   literal ports (see below).
3. **Follow `references/SECRETS.md`** for every `environment:` entry —
   placeholders and generated secrets are not interchangeable.
4. **Add icon/thumbnail** per `references/ARCHITECTURE.md` §5
   (self-hosted via jsdelivr, never upstream's own CDN).
5. **Add a README row** per `references/PUBLISHING_README.md`, in the
   same position as the app's row in the port ledger.
6. **Run `references/PRE_PUSH_CHECKLIST.md`** top to bottom before
   presenting the result as done.
7. **Deliver** `Apps/<AppName>/` (compose file, icon) plus a
   `REPO_UPDATES.md` holding the exact ledger row and README row for the
   user to paste, since this skill can't write to the repo. Present them
   with `present_files`.

Read `references/EXAMPLE.md` once if this is your first time through —
it shows all of the above applied to one real, fictional app.

## Non-negotiable behavior rules

- **Never put explanatory `#` comments in `docker-compose.yml`.** If
  something needs explaining, it goes in a real `x-casaos` field the
  store UI shows (see `references/ARCHITECTURE.md` §8 for exactly which
  field). The only exception is commenting out `thumbnail`/
  `screenshot_link` as a placeholder toggle.
- **Write `tips.before_install` like you're explaining it to a 4th
  grader.** Short sentences, everyday words, one instruction per numbered
  step. No restating why a design decision was made, no hedging, no
  digressions into how something works internally.
- **Validate YAML** before treating any manifest as done — a syntax error
  won't always fail loudly in the build action.
- **Never leave `<your-username>/<your-repo-name>`-style placeholders**
  in anything meant to be committed.
- **Use dynamic variables, not hardcoded values or `CHANGEME_*`, for
  anything ZimaOS reliably supplies.** Time zone is `$TZ`. A URL the app
  builds for itself defaults to `http://localhost:<published-port>`, like
  official ZimaOS apps do. A `CHANGEME_<IP>`-style placeholder is wrong for
  these. Explain the `localhost` limit in `tips.before_install` instead
  (see `references/VARIABLES.md`).
- **Do not use `$PORT`.** On a real M3U Editor install it resolved to the
  container port (36400), not the published port (8470), and the app broke.
  Use literal numbers: `target` is upstream's container port, `published`
  is the ledger port, app-URL vars use the published port, healthchecks use
  the container port.
- **Category must come from the fixed list** in
  `references/ARCHITECTURE.md` §3 — don't invent a new one.

## About `$PORT`

`$PORT` is in ZimaOS's variable list, but a real install showed it does
not equal `port_map`. Don't use it until a user confirms what it resolves
to. If they do, update `references/VARIABLES.md` first, then this skill.

When a user reports a broken install, ask for `docker logs <container>` and
`docker inspect <container> --format '{{range .Config.Env}}{{println .}}{{end}}'`
before guessing. The resolved env values show what ZimaOS actually filled in.

## When you're unsure

If upstream's install docs conflict with a rule here (e.g. they recommend
a config-file mount but `references/ARCHITECTURE.md` §4 prefers env
vars), follow this skill — it reflects real failures already hit in this
store, not theoretical concerns.

If the user points at an official ZimaOS app as a model (for example
Blinko's `NEXTAUTH_URL: http://localhost:1111`), treat it as evidence of
what ZimaOS accepts, and follow it for variables and URL defaults. Do not
copy its secrets: official apps ship fixed secrets in the manifest, and
this store generates a fresh random value instead (`references/SECRETS.md`).

When a default hurts real use (like `localhost` in a generated link), ship
the working default and say so plainly in the reply and in
`tips.before_install`. Don't hide it.
